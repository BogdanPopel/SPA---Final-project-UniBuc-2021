'use strict'

module.exports = require('ci-info').isCI
