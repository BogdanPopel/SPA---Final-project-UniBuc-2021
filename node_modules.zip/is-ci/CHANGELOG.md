# Changelog

## v2.0.0

Breaking changes:

* Drop support for Node.js end-of-life versions: 0.10, 0.12, 4, 5, 7,
  and 9

Other changes:

See [ci-info
changelog](https://github.com/watson/ci-info/blob/master/CHANGELOG.md#v200)
for a list of newly supported CI servers.
