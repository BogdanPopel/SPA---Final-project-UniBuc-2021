#!/usr/bin/env node
'use strict'

process.exit(require('./') ? 0 : 1)
